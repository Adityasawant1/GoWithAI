<?php
$em = $_POST['em'];
$ey = $_POST['ey'];
try{
   

$cn = new PDO ("pgsql:host=localhost;dbname=ty12429","postgres","root");
$sql = " select student.name,subject.title,exam.marks_obtained from student,subject,exam where exam.month='$em' and exam.year=$ey and student.seat_no = exam.seat_no and subject.sub_code = exam.sub_code";
$stmt = $cn->prepare($sql);

$stmt->execute();


}
catch(PDOEXCEPTION $e)
{
    echo "ERROR :". $e->getMessage();
}

?>