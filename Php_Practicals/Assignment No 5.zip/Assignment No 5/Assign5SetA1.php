<style>
    th,td{
        text-align:center;
        border:2px solid black;
    }
    table{
        border:2px solid black;
        border-collapse:collapse;
        width:50%;
    }
    
</style>

<?php
$hn = $_POST['hospital_name'];

try{

    $cn = new PDO("pgsql:host=localhost;dbname=hospital_db","postgres","root");
    var_dump($cn);
    $sql = "select doctor.* from doctor, hospital, doc_hosp WHERE hospital.hos_name = '$hn' and doctor.doc_no = doc_hosp.doc_no and hospital.hos_no = doc_hosp.hos_no;";
    $stmt=$cn->prepare($sql);

    echo "<table>";
    echo "<tr>
        <th>Doc No</th>
        <th>Doc Name</th>
        <th>Doc Addr</th>
        <th>Doc City</th>
        <th>Doc Area</th>
        </tr>";
    foreach($cn->query($sql) as $row)
    {
        echo "<tr>";
        echo "<td>$row[0]</td>"."<td>$row[1]</td>"."<td>$row[2]</td>"."<td>$row[3]</td>"."<td>$row[4]</td>";
        echo "</tr>";
    }
}
catch(PDOEXCEPTION $e)
{
    echo "ERROR :".$e->getMessage();
}
?>